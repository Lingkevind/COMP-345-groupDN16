#include "Hand.h"
#include<stdexcept>
using namespace std;

//int main() {
//	srand(time(NULL));
//	testCards();
//	return 0;
//}