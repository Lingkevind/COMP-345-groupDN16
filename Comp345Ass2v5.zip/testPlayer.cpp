﻿//#include <iostream>
//#include "Player.h"
//#include "GameEnginerDriver.cpp"
//#include "GameEngine.h";
//#include "CommandProcessing.h";



//using namespace std;

//int main()
//{
//    
//
//    cout << "player\n";
//    
//    //startupPhase();
//    testCommandProcessor(2);
//    testPlayer();
//    //testGameStates();
//    testCards();
//}
//
//inline void testStartupPhase(int n) {
//    CommandProcessor* cp = new CommandProcessor();
//    FileCommandProcessorAdapter* fcp = new FileCommandProcessorAdapter();
//    StateController* sc = new StateController(new StartState());
//    sc->startupPhase();
//
//}